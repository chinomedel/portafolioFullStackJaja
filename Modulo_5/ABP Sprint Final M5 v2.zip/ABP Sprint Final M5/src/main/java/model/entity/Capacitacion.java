package model.entity;

public class Capacitacion {

}
