/**
 * 
 */

 $(document).ready( function () {
		    $('.pulenta-tabla').DataTable();
} );
