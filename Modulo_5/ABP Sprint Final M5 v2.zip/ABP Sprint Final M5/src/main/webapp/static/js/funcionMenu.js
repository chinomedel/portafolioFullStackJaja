/**
 *  Funcionamiento menu movil
 */

function openNav() {
	document.getElementById("menu").style.width = "360px";
}
	 
function closeNav() {
	document.getElementById("menu").style.width = "0";
}