package cl.ElPiero.Modulo6Maven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Modulo6MavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(Modulo6MavenApplication.class, args);
	}

}
